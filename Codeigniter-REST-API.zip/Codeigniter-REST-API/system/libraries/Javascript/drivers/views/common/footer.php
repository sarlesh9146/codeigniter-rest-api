        <footer class="ftr pt30 pb30">
          <!-- <div class="container">
            this is footer
          </div> -->
        </footer>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
        <script src="assets/js/bootstrap.min.js"></script> 
        <script type="text/javascript" src="assets/js/angular.min.js"></script>
        <script type="text/javascript" src="assets/js/angular-route.js"></script>
        <script type="text/javascript" src="assets/app/app.js"></script>
        <script type="text/javascript" src="assets/app/services/routes.js"></script>
        <script type="text/javascript" src="assets/js/sweetalert.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="assets/js/angular-datatables.min.js"></script>

    </body>
</html>