<!DOCTYPE html>
<html>
<head>
	<title>welcome</title>
</head>
<body>

<p>Welcome to Codeigniter ..!! </p>

</body>
</html>
