<!DOCTYPE html>
<html lang="en" ng-app="testApp">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Innominds Tests</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/custom/custom.css">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/sweetalert.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.css">
  </head>
  <body>
    <header>
    <!-- <div><h2>This is header</h2></div>  -->
      <script type="application/javascript">var BASE_URL = "<?php echo base_url();?>";</script>
    </header>
    <ng-view></ng-view>
